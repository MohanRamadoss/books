
/**
 * Express application for NeuroPrompt.
 * @module app
 */
const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');
const fs = require('fs');
const multer = require('multer');
const cheerio = require('cheerio');
const FormData = require('form-data');

const app = express();
const port = 2024;
const promptsJsonFilePath = './public/data/prompts.json';
const upload = multer();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.json());

const db = new sqlite3.Database('./login.db');

app.use(express.static('public'));

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)");
	const insertUser = db.prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    insertUser.run('admin', 'admin');
    insertUser.run('tester', 'tester');
    insertUser.finalize();
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/login.html');
});


app.get('/dashboard', (req, res) => {
    fs.readFile(__dirname + '/public/lib.html', 'utf8', (err, libHtml) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error loading lib.html");
        }

        fs.readFile(__dirname + '/public/dashboard.html', 'utf8', (err, dashboardHtml) => {
            if (err) {
                console.error(err);
                return res.status(500).send("Error loading dashboard.html");
            }

            const $ = cheerio.load(dashboardHtml);
            $('#lib-content').html(libHtml);

            res.send($.html());
        });
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});

app.get('/lib', (req, res) => {
    res.sendFile(__dirname + '/public/lib.html');
});

app.post('/lib', (req, res) => {
    const requestData = req.body; // Parse the request body

    // Perform operations with the data
    // For example, you might save the data to a database or process it in some way

    console.log(requestData);

    // Send a response
    res.send('Received a POST request');
});



app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password], (err, row) => {
        if (err) {
            console.error(err.message);
            return;
        }

        if (row) {
            res.json({ success: true });
        } else {
            res.json({ success: false, message: 'Invalid username or password' });
        }
    });
});




app.post('/getResponse', async (req, res) => {
    try {
        const { message, model, apiKey, maxTokens, temperature } = req.body;
        
        const systemRole = 'You are a helpful assistant that answers questions on various topics and provides explanations.';

        const messagesArray = [
            { role: 'system', content: systemRole }
        ];

        messagesArray.push({ role: 'user' , content: message });

        const requestBody = {
            model: model,
            messages: messagesArray,
            max_tokens: maxTokens,
            temperature: temperature
        };

        const headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + apiKey,
        };

        const response = await axios.post('https://api.openai.com/v1/chat/completions', requestBody, { headers });

        res.header('Content-Type', 'application/json');
        res.json({ response: response.data.choices[0].message.content.replace(/^\\n+/, '') });
    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  app.put('/saveJson', (req, res) => {
    const jsonData = req.body;
    fs.writeFile(promptsJsonFilePath, JSON.stringify(jsonData, null, 2), (err) => {
      if (err) {
        console.error('Error writing to JSON file:', err);
        res.status(500).send('Error writing to JSON file');
      } else {
        console.log('JSON file updated successfully');
        res.sendStatus(200);
      }
    });
  });
  

  app.post('/getTranscription', upload.single('audio'), async (req, res) => {
    try {
      const audioBlob = req.file.buffer;
      const apiKey = req.body.apiKey;
      const formData = new FormData();
      formData.append('file', audioBlob, { filename: 'audio.mp3', contentType: req.file.mimetype });
      formData.append('model', 'whisper-1');
      formData.append('language', 'en');
      formData.append('response_format', 'json');
      formData.append('temperature', '0.2');

      const  config  = {
        headers: {
          "Content-Type": `multipart/form-data; boundary=${formData._boundary}`,
          "Authorization": 'Bearer ' + apiKey,
        },
      };

      const  response  =  await axios.post('https://api.openai.com/v1/audio/transcriptions', formData, config);

      if (response.status === 200) {
        res.header('Content-Type', 'application/json');
        res.json({ response: response.data.text});
      }
  
    } catch (error) {
      res.status(500).json({ error: 'Transcription error: Bad API key.' });
    }
  });

