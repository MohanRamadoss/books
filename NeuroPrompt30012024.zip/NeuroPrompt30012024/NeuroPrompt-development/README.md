Before you proceed with testing, please consider the following details and adjustments.


Adjustments for Running the Web Application:


	1) API Key Configuration:
	In the app.js file, locate the variable apiKEY and replace its current value with your API key.
	
	
	2) Prompts Database:
	The prompts database is a JSON file located in the public/data directory. This file is intended to be completed with your specific prompts. JSON format has been chosen for its simplicity,
	allowing easy editing and customization of prompts. The prototype includes 5 prompts related to Git, Docker, HR, and OS. You can add more prompts as needed.


Functionalities and Limitations of the Prototype:


	Prototype Nature:
	Please note that this is a prototype version, and some functionalities are not fully implemented.


	Limited Prompt Links:
	Only the prompts related to Git, Docker, HR, and OS have functional links. Other links are not operational in this version.


	Prompts Details Page:
	In the prompts details page, only the "Run Prompt" button is currently coded. The other buttons do not have implemented functionalities at this stage.


Deliverables Included:


	Source Code:
	The complete source code of the Node.js web application is included.


	Node.js Modules:
	All necessary Node.js modules and dependencies are included for your convenience.


	Dockerfile:
	A Dockerfile is provided if you choose to containerize the application. This can simplify the deployment process.

How to run the tests: 

As prerequisite, you need NodeJS or Docker installed. You have two options to run the webapp:

Option 1: Running with Node.js

    1) Open a terminal or command prompt.

    2) Navigate to the project directory.
	
    3) Run the following command: node app.js
	
    4) Open your web browser and navigate to http://localhost:2024
	

Option 2: Running with Docker

    1) Open a terminal or command prompt.

    2) Navigate to the project directory.
	
    3) Run the following command to build the Docker image: docker build -t NeuroPrompt .
	
    4) Run the following command: docker run -p 2024:2024 -d NeuroPrompt
	
    5) Open your web browser and navigate to http://localhost:2024


