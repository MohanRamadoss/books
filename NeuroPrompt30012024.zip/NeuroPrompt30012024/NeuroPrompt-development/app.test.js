const app = require('./app');

describe('app', () => {
  it('should create a valid request body', () => {
    const model = 'gpt-3.5-turbo';
    const messagesArray = ['Hello', 'How are you?'];
    const maxTokens = 100;
    const temperature = 0.8;

    const expectedRequestBody = {
      model: model,
      messages: messagesArray,
      max_tokens: maxTokens,
      temperature: temperature
    };

    const actualRequestBody = app.createRequestBody(model, messagesArray, maxTokens, temperature);

    expect(actualRequestBody).toEqual(expectedRequestBody);
  });
});