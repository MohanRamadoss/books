var promptText = '';
var promptDesc = '';
var promptRating = '';
var promptId = '';
var promptName = '';
var promptMainCategory = '';
var promptSubCategory = '';
var isRecording = false;
var mediaRecorder;
var chunks = [];

document.addEventListener('DOMContentLoaded', (event) => {
    const params = new URLSearchParams(window.location.search);
    promptName = params.get('text');
    promptId = params.get('id');
    var toolElement = document.getElementById("tool");
    toolElement.textContent = promptName;

    findPrompt(promptId)
    .then(() => {
        var promptTextElement = document.getElementById("prompt-text");
        promptTextElement.textContent = promptText;
        var promptDescElement = document.getElementById("prompt-desc");
        promptDescElement.textContent = promptDesc;
        var promptRatingElement = document.getElementById("prompt-rating");
        promptRatingElement.value = promptRating;
        if(!promptName)
        {
            toolElement.textContent = (promptSubCategory ?`${promptMainCategory}/${promptSubCategory}` : promptMainCategory);
        }
        else if(promptName && !promptMainCategory)
        {
            var categories = promptName.split('/');
            if (categories.length === 1) {
                promptMainCategory = categories[0];
            } else if (categories.length === 2) {
                promptMainCategory = categories[0];
                promptSubCategory = categories[1];
            }
        }
    })


    document.getElementById('runPromptLink').addEventListener('click', async function (event) {
        checkLogged();
        event.preventDefault(); 
        var promptTextElement = document.getElementById("prompt-text");
        promptText = promptTextElement.value;
        if(promptText!=='')
        {
            const spinner = document.getElementById('spinner');
            spinner.style.display = 'block';
            const result = await runPrompt(promptText);
            document.getElementById('prompt-res').value = result;
            spinner.style.display = 'none';
        }
        else
        {
            document.getElementById('prompt-res').value = '';
        }
        
    });

    const temperatureInput = document.getElementById("temperature-input");
    const temperatureValue = document.getElementById("temperature-value");
    const storedValue = localStorage.getItem("temperatureValue");
    temperatureInput.value = storedValue || "1";
    temperatureValue.textContent = temperatureInput.value;
    temperatureInput.addEventListener("input", function() {
        const value = temperatureInput.value;
        temperatureValue.textContent = value;
        localStorage.setItem("temperatureValue", value);
    });


    document.getElementById('savePromptLink').addEventListener('click', async function (event) {
        checkLogged();
        event.preventDefault(); 
        const spinner = document.getElementById('spinner');
        spinner.style.display = 'block';
        const result = await savePrompt(promptId);
        spinner.style.display = 'none';
    });

    document.getElementById('recordButton').addEventListener('click', async function (event) {
        checkLogged();
        event.preventDefault(); 
        const recordButton = document.getElementById('recordButton');
        if (!mediaRecorder || mediaRecorder.state === 'inactive') {
          startRecording();
          recordButton.textContent = 'Stop';
        } else {
          stopRecording();
          recordButton.textContent = 'Record';
        }
      });

});


async function findPrompt(query) {
    try {
        const jsonUrl = './data/prompts.json';
        const response = await fetch(jsonUrl);

        if (!response.ok) {
            throw new Error(`Failed to fetch JSON: ${response.status} ${response.statusText}`);
        }

        const prompts = await response.json();

        const result = prompts.find(prompt => prompt.id === query);
        if (result) {
            promptText = result.text || '';
            promptDesc = result.description || '';
            promptRating = result.rating || '';
            promptMainCategory = result.main_category || '';
            promptSubCategory = result.sub_category || '';
        }

    } catch (error) {
        console.error('Error fetching or parsing the JSON file:', error.message);
    }
}

function getApiKey()
{
    const apiKeyInput = document.getElementById("api-key-input");
    const apiKey =  apiKeyInput.value ? apiKeyInput.value : "empty key";
    return apiKey;
}

async function runPrompt(promptText) {
    
    const modelSelect = document.getElementById("model-select");
    const maxTokensInput = document.getElementById("max-tokens-input");
    const temperatureInput = document.getElementById("temperature-input");

    const model = modelSelect.value;
    const apiKey =  getApiKey();
    const maxTokens = isNaN(maxTokensInput.value) ? 1000 : Number(maxTokensInput.value);
    const temperature = Number(temperatureInput.value);

    const requestBody = JSON.stringify({
        message: promptText,
        model: model,
        apiKey: apiKey,
        maxTokens: maxTokens,
        temperature: temperature
      });

    const response = await fetch('/getResponse', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: requestBody,
    });
    const responseData = await response.json();

    if (response.ok) {
        return responseData.response;
    }
    else
    {
        return `Error: ${response.status} - ${response.statusText}`;
    }
}

function updateTemperatureValue(value) {
    const temperatureValue = document.getElementById("temperature-value");
    temperatureValue.textContent = value;
}

async function savePrompt(id) {
    
    if(!id || id == '#' || id == '')
    {
        return;
    }

    var promptTextElement = document.getElementById("prompt-text");
    promptText = promptTextElement.value;
    var promptDescElement = document.getElementById("prompt-desc");
    promptDesc = promptDescElement.value;
    var promptRatingElement = document.getElementById("prompt-rating");
    promptRating = promptRatingElement.value;
    
    try {
      const jsonUrl = './data/prompts.json';
      const response = await fetch(jsonUrl);
  
      if (!response.ok) {
        throw new Error(`Failed to fetch JSON: ${response.status} ${response.statusText}`);
      }
  
      const jsonData = await response.json();
  
      const prompt = jsonData.find((item) => item.id === id);
  
      if (prompt) {
        prompt.text = promptText;
        prompt.description = promptDesc;
        prompt.rating = promptRating;
      } else {
        const newPrompt = {
          id: id,
          main_category: promptMainCategory,
          sub_category: promptSubCategory,
          text: promptText,
          description: promptDesc,
          rating: promptRating
        };
        jsonData.push(newPrompt);
      }
  
      const updateResponse = await fetch('/saveJson', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(jsonData),
      });
  
      if (!updateResponse.ok) {
        throw new Error(`Failed to update JSON file: ${updateResponse.status} ${updateResponse.statusText}`);
      }
  
      alert(`Prompt saved successfully.`);

    } catch (error) {
      alert(error.message);
    }
  }

  async function transcribeAudio(audioBlob)  {
    const formData = new FormData();
    formData.append('audio', audioBlob);
    formData.append('apiKey', getApiKey()); 
  
    const response =  await fetch('/getTranscription', {
      method: 'POST',
      body: formData,
    });
  
    const responseData = await response.json()

    if(response.ok)
    {
      return responseData.response;
    }
   else
   {
    alert(responseData.error);
   }
  }

  async function stopRecording () {
    return new Promise((resolve, reject) => {
      mediaRecorder.addEventListener('stop', async () => {
        const spinner = document.getElementById('spinner');
            spinner.style.display = 'block';
        const audioBlob = new Blob(chunks, { type: 'audio/wav' });
        chunks = [];
        const transcribedText = await transcribeAudio(audioBlob);
        var promptTextElement = document.getElementById("prompt-text");
        promptTextElement.textContent = transcribedText;
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
        URL.revokeObjectURL(mediaRecorder.stream);
        resolve();
        spinner.style.display = 'none';
      });
      mediaRecorder.stop();
    });
  };

  async function startRecording () {
    var promptTextElement = document.getElementById("prompt-text");
    promptTextElement.textContent = "";
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.start();
    mediaRecorder.addEventListener('dataavailable', (e) => {
      chunks.push(e.data);
    });
  };
