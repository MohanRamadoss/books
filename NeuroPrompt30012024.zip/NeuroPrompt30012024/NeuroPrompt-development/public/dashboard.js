
document.addEventListener('DOMContentLoaded', function () {
    const searchButton = document.getElementById('searchButton');
    searchButton.addEventListener('click', handleSearch);
    const links = document.querySelectorAll('a');
    links.forEach((link) => {
        const hrefValue = link.getAttribute('href');
        link.addEventListener('click', (event) => {
            if (hrefValue.includes(".html") ) {
                checkLogged();
                window.location.href = hrefValue;
            }
            else
            {
                event.preventDefault();
                let text = event.target.textContent;
                let parentListItem = event.target.closest('ul').previousElementSibling;
                if (parentListItem && parentListItem.nodeName === 'LI') {
                    let parentText = parentListItem.textContent.replace(':', '/');
                    text = `${parentText}${text}`;
                }
                window.location.href = 'prompt.html?id=' + encodeURIComponent(hrefValue) +'&text=' + encodeURIComponent(text);
            }
        });
    });

});

async function handleSearch() {

    const searchTerm = document.getElementById('search').value;
    var promptId = '';
    try {
        const jsonUrl = './data/prompts.json';
        const response = await fetch(jsonUrl);

        if (response.ok) {
            const prompts = await response.json();

            const matchingPrompt = prompts.find(prompt => {
                return (
                    prompt.main_category.toLowerCase() === searchTerm.toLowerCase() ||
                    (prompt.sub_category && prompt.sub_category.toLowerCase() === searchTerm.toLowerCase())
                );
            });
            promptId = matchingPrompt.id || '';
        }
    } catch (error) {
        console.error('Error fetching or parsing the JSON file:', error.message);
    }

    if(promptId !== '')
    {
        window.location.href = 'prompt.html?id=' + encodeURIComponent(promptId);
    }
    else
    {
        alert('Prompt not found!');
    }
    
}

