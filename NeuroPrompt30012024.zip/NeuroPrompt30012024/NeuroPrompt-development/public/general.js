function logout() {
    localStorage.setItem("isLogged", false);
    window.location.href = "/login.html"; 
}

function home() {
    window.location.href = "/dashboard.html"; 
}

function checkLogged()
{
    const isLogged = localStorage.getItem("isLogged");
    if(isLogged == null || isLogged == "false" )
    {
        window.location.href = "/login.html"; 
    }
}