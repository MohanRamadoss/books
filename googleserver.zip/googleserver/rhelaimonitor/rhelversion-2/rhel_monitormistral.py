# [Previous imports remain the same]

class RHELMonitor:  # Changed from UbuntuMonitor
    def __init__(self):
        """Initialize monitoring system."""
        self.setup_logging()

    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = os.path.expanduser('~/rhel_monitor/logs')  # Changed directory name
        os.makedirs(log_dir, exist_ok=True)

        logging.basicConfig(
            filename=os.path.join(log_dir, 'monitor.log'),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    # [run_command, get_network_metrics, get_top_processes methods remain the same]

    def check_critical_services(self) -> Dict[str, str]:
        """Check status of critical services."""
        # Updated for common RHEL services
        critical_services = ['sshd', 'httpd', 'mariadb', 'firewalld', 'chronyd']
        service_status = {}

        for service in critical_services:
            cmd = self.run_command(f"systemctl is-active {service}")
            service_status[service] = cmd["output"].strip() if cmd["success"] else "unknown"

        return service_status

    def get_system_metrics(self) -> SystemMetrics:
        """Collect system metrics."""
        try:
            # System info
            uname = platform.uname()
            hostname = uname.node
            kernel = uname.release

            # Get OS version for RHEL
            try:
                with open('/etc/redhat-release') as f:
                    os_version = f.read().strip()
            except:
                os_version = "RHEL (version unknown)"

            # Get uptime
            uptime_cmd = self.run_command("uptime -p")
            uptime = uptime_cmd["output"].strip() if uptime_cmd["success"] else "Unknown"

            # [Rest of the resource usage collection remains the same]

            # Update information
            updates = self.check_updates()

            # Additional metrics
            network_metrics = self.get_network_metrics()
            top_processes = self.get_top_processes()
            service_status = self.check_critical_services()
            load_average = self.get_load_average()

            return SystemMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                kernel_version=kernel,
                uptime=uptime,
                cpu_usage=cpu_usage,
                memory_used=memory.used / (1024**3),
                memory_total=memory.total / (1024**3),
                swap_used=swap.used / (1024**3),
                swap_total=swap.total / (1024**3),
                disk_usage=disk_metrics,
                updates_pending=updates['total'],
                security_updates=updates['security'],
                network_metrics=network_metrics,
                top_processes=top_processes,
                service_status=service_status,
                load_average=load_average
            )

        except Exception as e:
            logging.error(f"Error collecting metrics: {e}")
            raise

    def check_updates(self) -> Dict[str, int]:
        """Check for system updates using dnf."""
        try:
            # Check for updates using dnf
            check_cmd = self.run_command("sudo dnf check-update --quiet")
            security_cmd = self.run_command("sudo dnf list-security --quiet")

            updates = {
                'total': 0,
                'security': 0
            }

            # Count total updates
            if check_cmd["success"] or check_cmd["error"].returncode == 100:  # 100 means updates available
                lines = check_cmd["output"].split('\n')
                updates['total'] = len([l for l in lines if l and not l.startswith(('Last metadata', 'Obsoleting'))])

            # Count security updates
            if security_cmd["success"]:
                lines = security_cmd["output"].split('\n')
                updates['security'] = len([l for l in lines if 'Security' in l])

            return updates

        except Exception as e:
            logging.error(f"Error checking updates: {e}")
            return {'total': 0, 'security': 0}

    def analyze_metrics(self, metrics: SystemMetrics) -> Dict[str, Any]:
        """Use Mistral to analyze system metrics."""
        prompt = f"""
        As a system administrator, analyze these RHEL 9 server metrics:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Load Average:
        - 1 minute: {metrics.load_average['1min']:.2f}
        - 5 minutes: {metrics.load_average['5min']:.2f}
        - 15 minutes: {metrics.load_average['15min']:.2f}

        Network Metrics:
        {json.dumps(metrics.network_metrics, indent=2)}

        Top Processes:
        {json.dumps(metrics.top_processes, indent=2)}

        Service Status:
        {json.dumps(metrics.service_status, indent=2)}

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Please provide a detailed analysis including:
        1. System health assessment
        2. Resource usage analysis
        3. Network performance analysis
        4. Process and service status evaluation
        5. Security recommendations
        6. Performance optimization suggestions
        7. Maintenance tasks needed

        Format the response in markdown with clear sections and bullet points.
        """

        try:
            response = ollama.chat(
                model='mistral',
                messages=[{'role': 'user', 'content': prompt}]
            )

            return {
                'timestamp': metrics.timestamp,
                'analysis': response.message.content,
                'metrics': metrics.__dict__
            }
        except Exception as e:
            logging.error(f"Error in AI analysis: {e}")
            return {
                'timestamp': metrics.timestamp,
                'analysis': f"Error performing AI analysis: {str(e)}",
                'metrics': metrics.__dict__
            }

    # [print_report method remains the same except for title changes]

    def monitor(self, interval: int = 300):
        """Run continuous monitoring."""
        print("\nRHEL 9 Server Monitoring System")  # Updated title
        print("="*50)
        print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("Log Directory: ~/rhel_monitor/logs")  # Updated directory
        print("="*50)

        try:
            while True:
                metrics = self.get_system_metrics()
                analysis = self.analyze_metrics(metrics)
                self.print_report(metrics, analysis)

                # Save to log file
                log_dir = os.path.expanduser('~/rhel_monitor/logs')
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                with open(os.path.join(log_dir, f'metrics_{timestamp}.json'), 'w') as f:
                    json.dump(analysis, f, indent=2)

                time.sleep(interval)

        except KeyboardInterrupt:
            print("\nMonitoring stopped by user")
        except Exception as e:
            print(f"\nError: {e}")
            logging.error(f"Monitoring failed: {e}")

if __name__ == "__main__":
    monitor = RHELMonitor()
    monitor.monitor()