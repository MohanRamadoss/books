import ollama
import subprocess
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import asyncio
import aiohttp

@dataclass
class PatchInfo:
    """Store patch analysis information"""
    timestamp: str
    total_updates: int
    security_updates: int
    bugfix_updates: int
    enhancement_updates: int
    critical_updates: int
    system_packages: List[str]
    kernel_updates: List[str]
    service_impacting: List[str]
    last_patched: str
    reboot_required: bool
    update_details: Dict[str, Any]

class RHELPatchAnalyzer:
    def __init__(self, log_dir: str = "~/rhel_patch_analysis/logs", 
                 model_name: str = "llama3.2:latest",
                 max_workers: int = 4,
                 cache_timeout: int = 3600):
        """Initialize RHEL patch analyzer with enhanced performance settings."""
        self.log_dir = Path(os.path.expanduser(log_dir))
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._setup_logging()  # Fixed method name
        self.llm = ollama.Client()
        self.model_name = model_name
        self.max_workers = max_workers
        self.cache_timeout = cache_timeout
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self._command_cache = {}

    def _setup_logging(self):  # Added missing logging setup method
        """Setup logging configuration."""
        logging.basicConfig(
            filename=self.log_dir / "patch_analysis.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    @lru_cache(maxsize=128)
    def run_command(self, command_tuple: tuple) -> Dict[str, Any]:
        """Execute shell command with caching."""
        command = list(command_tuple)
        cache_key = ' '.join(command)

        if cache_key in self._command_cache:
            cache_time, result = self._command_cache[cache_key]
            if (datetime.now() - cache_time).seconds < self.cache_timeout:
                return result

        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            output = {
                "success": result.returncode in [0, 100],
                "output": result.stdout,
                "error": result.stderr,
                "code": result.returncode
            }
            self._command_cache[cache_key] = (datetime.now(), output)
            return output
        except Exception as e:
            logging.error(f"Command execution failed: {e}")
            return {"success": False, "error": str(e), "output": "", "code": -1}

    def check_reboot_required(self) -> bool:
        """Check if system requires reboot after updates."""
        try:
            kernel_result = self.run_command(tuple(["rpm", "-q", "kernel"]))
            current_kernel = self.run_command(tuple(["uname", "-r"]))

            return (kernel_result["success"] and current_kernel["success"] and
                   current_kernel["output"].strip() not in kernel_result["output"])
        except Exception as e:
            logging.error(f"Error checking reboot requirement: {e}")
            return False

    def get_last_patch_date(self) -> str:
        """Get the date of last system update."""
        try:
            result = self.run_command(tuple(["rpm", "-qa", "--last"]))
            if result["success"]:
                first_line = result["output"].split('\n')[0]
                return first_line.split('  ')[-1].strip()
            return "Unknown"
        except Exception as e:
            logging.error(f"Error getting last patch date: {e}")
            return "Unknown"

    def get_update_details(self) -> Dict[str, Any]:
        """Optimized update details collection using parallel processing."""
        updates = {
            "security": [], "bugfix": [], "enhancement": [],
            "kernel": [], "critical": [], "service_impacting": []
        }

        def parallel_command_execution():
            commands = [
                ["dnf", "list", "updates", "--available"],
                ["dnf", "list", "updates", "--security"],
                ["dnf", "updateinfo", "list"]
            ]
            return list(self.executor.map(
                lambda cmd: self.run_command(tuple(cmd)), 
                commands
            ))

        try:
            results = parallel_command_execution()

            if results[0]["success"]:
                for line in results[0]["output"].split('\n'):
                    if line and not line.startswith(('Last metadata', 'Updated')):
                        try:
                            package = line.split()[0]
                            if 'kernel' in package.lower():
                                updates["kernel"].append(package)
                            if any(svc in package.lower() for svc in ['systemd', 'dbus', 'network', 'docker', 'container']):
                                updates["service_impacting"].append(package)
                        except IndexError:
                            continue

            if results[1]["success"]:
                updates["security"] = [
                    line.split()[0] for line in results[1]["output"].split('\n')
                    if line and not line.startswith(('Last metadata', 'Updated'))
                ]

            if results[2]["success"]:
                for line in results[2]["output"].split('\n'):
                    if 'Critical' in line:
                        pkg = line.split()[-1]
                        updates["critical"].append(pkg)

            return updates

        except Exception as e:
            logging.error(f"Error getting update details: {e}")
            return updates

    def analyze_patches(self) -> PatchInfo:
        """Collect and analyze patch information."""
        try:
            updates = self.get_update_details()

            patch_info = PatchInfo(
                timestamp=datetime.now().isoformat(),
                total_updates=len(updates.get("security", [])) + len(updates.get("bugfix", [])) + len(updates.get("enhancement", [])),
                security_updates=len(updates.get("security", [])),
                bugfix_updates=len(updates.get("bugfix", [])),
                enhancement_updates=len(updates.get("enhancement", [])),
                critical_updates=len(updates.get("critical", [])),
                system_packages=[pkg for pkg in updates.get("security", []) if any(sys_pkg in pkg.lower() for sys_pkg in ['systemd', 'glibc', 'openssl'])],
                kernel_updates=updates.get("kernel", []),
                service_impacting=updates.get("service_impacting", []),
                last_patched=self.get_last_patch_date(),
                reboot_required=self.check_reboot_required(),
                update_details=updates
            )

            return patch_info
        except Exception as e:
            logging.error(f"Error analyzing patches: {e}")
            raise

    async def async_generate_analysis(self, prompt: str) -> str:
        """Asynchronous AI analysis generation."""
        try:
            response = await asyncio.to_thread(
                self.llm.generate,
                model=self.model_name,
                prompt=prompt,
                stream=False
            )
            return response['response']
        except Exception as e:
            logging.error(f"Error in async AI analysis: {e}")
            return f"Error performing analysis: {str(e)}"

    def _create_analysis_prompt(self, patch_info: PatchInfo) -> str:
        """Create optimized prompt for LLM."""
        return f"""
        Analyze RHEL system patch status (concise format):
        Updates: {patch_info.total_updates} total, {patch_info.security_updates} security, {patch_info.critical_updates} critical
        System: {len(patch_info.system_packages)} system packages, {len(patch_info.kernel_updates)} kernel updates
        Status: Last patched {patch_info.last_patched}, Reboot required: {patch_info.reboot_required}

        Provide:
        1. Risk Assessment (security, impact, vulnerabilities)
        2. Prioritized recommendations
        3. Implementation steps
        4. Best practices

        Format: Bullet points, specific actions
        """

    async def generate_report(self) -> None:
        """Generate comprehensive patch analysis report."""
        try:
            patch_info = self.analyze_patches()
            analysis = await self.async_generate_analysis(self._create_analysis_prompt(patch_info))

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = self.log_dir / f"patch_analysis_{timestamp}.txt"

            with open(report_file, 'w') as f:
                f.write("RHEL Patch Analysis Report\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write("=" * 80 + "\n\n")

                # Write report sections
                f.write("Executive Summary\n")
                f.write("-" * 50 + "\n")
                f.write(f"Total Updates: {patch_info.total_updates}\n")
                f.write(f"Security Updates: {patch_info.security_updates}\n")
                f.write(f"Critical Updates: {patch_info.critical_updates}\n")
                f.write(f"Last Patched: {patch_info.last_patched}\n")
                f.write(f"Reboot Required: {'Yes' if patch_info.reboot_required else 'No'}\n\n")

                f.write("AI Analysis and Recommendations\n")
                f.write("-" * 50 + "\n")
                f.write(analysis)
                f.write("\n\n")

                # Write detailed information
                f.write("Detailed Update Information\n")
                f.write("-" * 50 + "\n")

                sections = [
                    ("Kernel Updates", patch_info.kernel_updates),
                    ("Service-Impacting Updates", patch_info.service_impacting),
                    ("System Package Updates", patch_info.system_packages)
                ]

                for section_name, updates in sections:
                    f.write(f"\n{section_name}:\n")
                    for update in updates:
                        f.write(f"- {update}\n")

                f.write("\n" + "=" * 80 + "\n")
                f.write("Raw Update Data:\n")
                f.write(json.dumps(patch_info.update_details, indent=2))

            logging.info(f"Analysis report generated: {report_file}")
            print(f"\nReport generated: {report_file}")

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            print(f"Error generating report: {e}")

async def main():
    """Main function to run the patch analyzer."""
    print("\n=== RHEL Patch Analysis System ===")
    analyzer = RHELPatchAnalyzer()

    try:
        print("\nAnalyzing system patches...")
        await analyzer.generate_report()
        print("\nAnalysis complete. Check the logs directory for the report.")

    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Error in main: {e}")

if __name__ == "__main__":
    asyncio.run(main())