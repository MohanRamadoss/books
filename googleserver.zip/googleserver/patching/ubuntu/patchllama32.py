import subprocess
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import asyncio
import ollama

@dataclass
class PatchInfo:
    """Store patch analysis information"""
    timestamp: str
    total_updates: int
    security_updates: int
    bugfix_updates: int
    enhancement_updates: int
    critical_updates: int
    system_packages: List[str]
    kernel_updates: List[str]
    service_impacting: List[str]
    last_patched: str
    reboot_required: bool
    update_details: Dict[str, Any]

class LinuxPatchAnalyzer:
    def __init__(self, 
                 log_dir: str = "~/patch_analysis/logs",
                 max_workers: int = 4,
                 cache_timeout: int = 3600):
        """Initialize patch analyzer."""
        self.log_dir = Path(os.path.expanduser(log_dir))
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._setup_logging()
        self.llm = ollama.Client()
        self.max_workers = max_workers
        self.cache_timeout = cache_timeout
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self._command_cache = {}
        self.is_ubuntu = self._check_is_ubuntu()

    def _setup_logging(self):
        """Setup logging configuration."""
        logging.basicConfig(
            filename=self.log_dir / "patch_analysis.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def _check_is_ubuntu(self) -> bool:
        """Check if system is Ubuntu."""
        try:
            result = subprocess.run(['lsb_release', '-i'], capture_output=True, text=True)
            return 'Ubuntu' in result.stdout
        except:
            return False

    @lru_cache(maxsize=128)
    def run_command(self, command_tuple: tuple) -> Dict[str, Any]:
        """Execute shell command with caching."""
        command = list(command_tuple)
        cache_key = ' '.join(command)

        if cache_key in self._command_cache:
            cache_time, result = self._command_cache[cache_key]
            if (datetime.now() - cache_time).seconds < self.cache_timeout:
                return result

        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            output = {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
                "code": result.returncode
            }
            self._command_cache[cache_key] = (datetime.now(), output)
            return output
        except Exception as e:
            logging.error(f"Command execution failed: {e}")
            return {"success": False, "error": str(e), "output": "", "code": -1}

    def check_reboot_required(self) -> bool:
        """Check if system requires reboot after updates."""
        if self.is_ubuntu:
            return os.path.exists('/var/run/reboot-required')
        else:
            try:
                kernel_result = self.run_command(tuple(["rpm", "-q", "kernel"]))
                current_kernel = self.run_command(tuple(["uname", "-r"]))
                return (kernel_result["success"] and current_kernel["success"] and
                       current_kernel["output"].strip() not in kernel_result["output"])
            except Exception as e:
                logging.error(f"Error checking reboot requirement: {e}")
                return False

    def get_last_patch_date(self) -> str:
        """Get the date of last system update."""
        try:
            if self.is_ubuntu:
                result = self.run_command(tuple(["stat", "-c", "%y", "/var/log/apt/history.log"]))
            else:
                result = self.run_command(tuple(["rpm", "-qa", "--last"]))

            if result["success"]:
                if self.is_ubuntu:
                    return result["output"].strip()
                else:
                    return result["output"].split('\n')[0].split('  ')[-1].strip()
            return "Unknown"
        except Exception as e:
            logging.error(f"Error getting last patch date: {e}")
            return "Unknown"

    async def get_update_details(self) -> Dict[str, Any]:
        """Get detailed information about available updates."""
        updates = {
            "security": [], "bugfix": [], "enhancement": [],
            "kernel": [], "critical": [], "service_impacting": []
        }

        async def execute_commands():
            if self.is_ubuntu:
                await asyncio.to_thread(self.run_command, tuple(["apt-get", "update"]))
                commands = [
                    ["apt", "list", "--upgradable"],
                    ["apt-get", "-s", "dist-upgrade"],
                    ["unattended-upgrades", "--dry-run", "--debug"]
                ]
            else:
                commands = [
                    ["dnf", "list", "updates", "--available"],
                    ["dnf", "list", "updates", "--security"],
                    ["dnf", "updateinfo", "list"]
                ]

            tasks = [
                asyncio.to_thread(self.run_command, tuple(cmd))
                for cmd in commands
            ]
            return await asyncio.gather(*tasks)

        try:
            results = await execute_commands()

            if self.is_ubuntu:
                if results[0]["success"]:
                    for line in results[0]["output"].split('\n'):
                        if line and not line.startswith('Listing...'):
                            try:
                                package = line.split('/')[0]
                                if 'linux-' in package:
                                    updates["kernel"].append(package)
                                if any(svc in package for svc in ['systemd', 'dbus', 'network', 'docker', 'containerd']):
                                    updates["service_impacting"].append(package)
                            except IndexError:
                                continue
            else:
                if results[0]["success"]:
                    for line in results[0]["output"].split('\n'):
                        if line and not line.startswith(('Last metadata', 'Updated')):
                            try:
                                package = line.split()[0]
                                if 'kernel' in package.lower():
                                    updates["kernel"].append(package)
                                if any(svc in package.lower() for svc in ['systemd', 'dbus', 'network', 'docker', 'container']):
                                    updates["service_impacting"].append(package)
                            except IndexError:
                                continue

            return updates

        except Exception as e:
            logging.error(f"Error getting update details: {e}")
            return updates

    def _create_optimized_llama_prompt(self, patch_info: PatchInfo) -> str:
        """Create highly optimized prompt for llama-3.2."""
        os_type = "Ubuntu" if self.is_ubuntu else "RHEL/CentOS"
        return f"""[SYSTEM]
You are an expert Linux system administrator and security analyst. Analyze the following patch data and provide a detailed, professional assessment.

[CONTEXT]
Operating System: {os_type} Linux
Analysis Timestamp: {patch_info.timestamp}
Current Patch Status:
* Total Pending Updates: {patch_info.total_updates}
* Security Updates: {patch_info.security_updates}
* Critical Updates: {patch_info.critical_updates}
* Kernel Updates Present: {len(patch_info.kernel_updates)}
* Service-Impacting Changes: {len(patch_info.service_impacting)}
* Last System Patch: {patch_info.last_patched}
* Reboot Required: {patch_info.reboot_required}

Kernel Updates: {', '.join(patch_info.kernel_updates) if patch_info.kernel_updates else 'None'}
Critical Services Affected: {', '.join(patch_info.service_impacting) if patch_info.service_impacting else 'None'}

[TASK]
Provide a comprehensive security and patch analysis following this exact structure:

1. RISK ASSESSMENT
<focus on immediate security implications>
- Critical Vulnerabilities:
- Security Impact Level:
- System Stability Risk:
- Service Disruption Potential:

2. PRIORITIZED ACTIONS
<list in order of urgency>
- Immediate Actions Required:
- High Priority Updates:
- Service Impact Mitigations:
- Recommended Update Sequence:

3. TECHNICAL IMPLEMENTATION
<provide specific commands and steps>
Pre-Update Tasks:
Update Procedure:
Post-Update Verification:
4. ROLLBACK PLAN
<detail recovery steps>
- Snapshot/Backup Requirements:
- Rollback Commands:
- Service Recovery Steps:

[OUTPUT REQUIREMENTS]
- Be concise but thorough
- Include specific commands where relevant
- Prioritize security implications
- Consider system stability
- Focus on practical implementation

[/TASK]
"""

    async def generate_llama_analysis(self, prompt: str) -> str:
        """Generate analysis using optimized llama-3.2 parameters."""
        try:
            response = await asyncio.to_thread(
                self.llm.generate,
                model="llama3.2:latest",
                prompt=prompt,
                options={
                    "temperature": 0.7,
                    "top_p": 0.95,
                    "top_k": 40,
                    "num_predict": 2048,
                    "repeat_penalty": 1.1,
                    "presence_penalty": 0.1,
                    "frequency_penalty": 0.1,
                    "stop": ["[/TASK]", "[END]", "###"],
                    "seed": 42,
                    "num_ctx": 4096,
                    "num_thread": 4
                }
            )
            return response['response']
        except Exception as e:
            logging.error(f"Error in Llama analysis: {e}")
            return f"Error performing analysis: {str(e)}"

    async def analyze_patches(self) -> PatchInfo:
        """Analyze patch information."""
        try:
            updates = await self.get_update_details()

            patch_info = PatchInfo(
                timestamp=datetime.now().isoformat(),
                total_updates=len(updates.get("security", [])) + len(updates.get("bugfix", [])) + len(updates.get("enhancement", [])),
                security_updates=len(updates.get("security", [])),
                bugfix_updates=len(updates.get("bugfix", [])),
                enhancement_updates=len(updates.get("enhancement", [])),
                critical_updates=len(updates.get("critical", [])),
                system_packages=[pkg for pkg in updates.get("security", []) if any(sys_pkg in pkg.lower() for sys_pkg in ['systemd', 'glibc', 'openssl'])],
                kernel_updates=updates.get("kernel", []),
                service_impacting=updates.get("service_impacting", []),
                last_patched=self.get_last_patch_date(),
                reboot_required=self.check_reboot_required(),
                update_details=updates
            )

            return patch_info
        except Exception as e:
            logging.error(f"Error analyzing patches: {e}")
            raise

    async def generate_report(self) -> None:
        """Generate comprehensive patch analysis report."""
        try:
            patch_info = await self.analyze_patches()
            optimized_prompt = self._create_optimized_llama_prompt(patch_info)
            analysis = await self.generate_llama_analysis(optimized_prompt)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = self.log_dir / f"patch_analysis_{timestamp}.txt"

            with open(report_file, 'w') as f:
                f.write(f"Linux Patch Analysis Report ({self.is_ubuntu and 'Ubuntu' or 'RHEL/CentOS'})\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write("=" * 80 + "\n\n")

                sections = [
                    ("Executive Summary", {
                        "Total Updates": patch_info.total_updates,
                        "Security Updates": patch_info.security_updates,
                        "Critical Updates": patch_info.critical_updates,
                        "Last Patched": patch_info.last_patched,
                        "Reboot Required": "Yes" if patch_info.reboot_required else "No"
                    }),
                    ("AI Analysis and Recommendations", {"content": analysis}),
                    ("Kernel Updates", patch_info.kernel_updates),
                    ("Service-Impacting Updates", patch_info.service_impacting),
                    ("System Package Updates", patch_info.system_packages)
                ]

                for section_name, content in sections:
                    f.write(f"\n{section_name}\n")
                    f.write("-" * 50 + "\n")

                    if isinstance(content, dict):
                        if "content" in content:
                            f.write(content["content"])
                        else:
                            for key, value in content.items():
                                f.write(f"{key}: {value}\n")
                    elif isinstance(content, list):
                        for item in content:
                            f.write(f"- {item}\n")

                f.write("\n" + "=" * 80 + "\n")
                f.write("Raw Update Data:\n")
                f.write(json.dumps(patch_info.update_details, indent=2))

            logging.info(f"Analysis report generated: {report_file}")
            print(f"\nReport generated: {report_file}")

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            print(f"Error generating report: {e}")

async def main():
    """Main function to run the patch analyzer."""
    print("\n=== Linux Patch Analysis System ===")
    analyzer = LinuxPatchAnalyzer()

    try:
        print("\nAnalyzing system patches...")
        await analyzer.generate_report()
        print("\nAnalysis complete. Check the logs directory for the report.")

    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Error in main: {e}")

if __name__ == "__main__":
    asyncio.run(main())