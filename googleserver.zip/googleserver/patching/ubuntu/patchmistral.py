import ollama
import subprocess
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import asyncio

@dataclass
class PatchInfo:
    """Store patch analysis information"""
    timestamp: str
    total_updates: int
    security_updates: int
    bugfix_updates: int
    enhancement_updates: int
    critical_updates: int
    system_packages: List[str]
    kernel_updates: List[str]
    service_impacting: List[str]
    last_patched: str
    reboot_required: bool
    update_details: Dict[str, Any]

class UbuntuPatchAnalyzer:
    def __init__(self, 
                 log_dir: str = "~/ubuntu_patch_analysis/logs",
                 model_name: str = "mistral:latest",
                 max_workers: int = 4,
                 cache_timeout: int = 3600):
        """Initialize Ubuntu patch analyzer."""
        self.log_dir = Path(os.path.expanduser(log_dir))
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._setup_logging()
        self.llm = ollama.Client()
        self.model_name = model_name
        self.max_workers = max_workers
        self.cache_timeout = cache_timeout
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self._command_cache = {}

    def _setup_logging(self):
        """Setup logging configuration."""
        logging.basicConfig(
            filename=self.log_dir / "patch_analysis.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    @lru_cache(maxsize=128)
    def run_command(self, command_tuple: tuple) -> Dict[str, Any]:
        """Execute shell command with caching."""
        command = list(command_tuple)
        cache_key = ' '.join(command)

        if cache_key in self._command_cache:
            cache_time, result = self._command_cache[cache_key]
            if (datetime.now() - cache_time).seconds < self.cache_timeout:
                return result

        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            output = {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr,
                "code": result.returncode
            }
            self._command_cache[cache_key] = (datetime.now(), output)
            return output
        except Exception as e:
            logging.error(f"Command execution failed: {e}")
            return {"success": False, "error": str(e), "output": "", "code": -1}

    def check_reboot_required(self) -> bool:
        """Check if system requires reboot after updates."""
        try:
            return os.path.exists('/var/run/reboot-required')
        except Exception as e:
            logging.error(f"Error checking reboot requirement: {e}")
            return False

    def get_last_patch_date(self) -> str:
        """Get the date of last system update."""
        try:
            result = self.run_command(tuple(["stat", "-c", "%y", "/var/log/apt/history.log"]))
            if result["success"]:
                return result["output"].strip()
            return "Unknown"
        except Exception as e:
            logging.error(f"Error getting last patch date: {e}")
            return "Unknown"

    async def get_update_details(self) -> Dict[str, Any]:
        """Get detailed information about available updates."""
        updates = {
            "security": [], "bugfix": [], "enhancement": [],
            "kernel": [], "critical": [], "service_impacting": []
        }

        async def execute_commands():
            # Update package lists first
            await asyncio.to_thread(self.run_command, tuple(["apt-get", "update"]))

            commands = [
                ["apt", "list", "--upgradable"],
                ["apt-get", "-s", "dist-upgrade"],
                ["unattended-upgrades", "--dry-run", "--debug"]
            ]
            tasks = [
                asyncio.to_thread(self.run_command, tuple(cmd))
                for cmd in commands
            ]
            return await asyncio.gather(*tasks)

        try:
            results = await execute_commands()

            # Process upgradable packages
            if results[0]["success"]:
                for line in results[0]["output"].split('\n'):
                    if line and not line.startswith('Listing...'):
                        try:
                            package = line.split('/')[0]
                            if 'linux-' in package:
                                updates["kernel"].append(package)
                            if any(svc in package for svc in ['systemd', 'dbus', 'network', 'docker', 'containerd']):
                                updates["service_impacting"].append(package)
                        except IndexError:
                            continue

            # Process security updates
            if results[2]["success"]:
                for line in results[2]["output"].split('\n'):
                    if 'security' in line.lower():
                        try:
                            package = line.split()[0]
                            updates["security"].append(package)
                            if 'high' in line.lower() or 'critical' in line.lower():
                                updates["critical"].append(package)
                        except IndexError:
                            continue

            return updates

        except Exception as e:
            logging.error(f"Error getting update details: {e}")
            return updates

    async def generate_analysis(self, prompt: str) -> str:
        """Generate analysis using Mistral model."""
        try:
            response = await asyncio.to_thread(
                self.llm.generate,
                model=self.model_name,
                prompt=prompt,
                options={
                    "temperature": 0.7,
                    "top_p": 0.95,
                    "num_predict": 2048,
                    "stop": ["###"]
                }
            )
            return response['response']
        except Exception as e:
            logging.error(f"Error in AI analysis: {e}")
            return f"Error performing analysis: {str(e)}"

    def _create_analysis_prompt(self, patch_info: PatchInfo) -> str:
        """Create optimized prompt for Mistral."""
        return f"""
        As an Ubuntu system administrator, analyze this system's patch status and provide recommendations:

        Current Status:
        - Total Updates: {patch_info.total_updates}
        - Security Updates: {patch_info.security_updates}
        - Critical Updates: {patch_info.critical_updates}
        - Kernel Updates: {len(patch_info.kernel_updates)}
        - Service-Impacting: {len(patch_info.service_impacting)}
        - Last Patched: {patch_info.last_patched}
        - Reboot Required: {patch_info.reboot_required}

        Provide a detailed analysis covering:

        1. Security Assessment:
        - Critical vulnerabilities
        - Security implications
        - Risk levels

        2. Priority Actions:
        - Immediate security updates
        - System package updates
        - Service impact handling

        3. Update Implementation:
        - Pre-update checks
        - Update commands
        - Post-update verification
        - Rollback steps

        Format response in clear bullet points with specific Ubuntu commands.
        ###
        """

    async def analyze_patches(self) -> PatchInfo:
        """Analyze patch information."""
        try:
            updates = await self.get_update_details()

            patch_info = PatchInfo(
                timestamp=datetime.now().isoformat(),
                total_updates=len(updates.get("security", [])) + len(updates.get("bugfix", [])) + len(updates.get("enhancement", [])),
                security_updates=len(updates.get("security", [])),
                bugfix_updates=len(updates.get("bugfix", [])),
                enhancement_updates=len(updates.get("enhancement", [])),
                critical_updates=len(updates.get("critical", [])),
                system_packages=[pkg for pkg in updates.get("security", []) if any(sys_pkg in pkg.lower() for sys_pkg in ['systemd', 'glibc', 'openssl'])],
                kernel_updates=updates.get("kernel", []),
                service_impacting=updates.get("service_impacting", []),
                last_patched=self.get_last_patch_date(),
                reboot_required=self.check_reboot_required(),
                update_details=updates
            )

            return patch_info
        except Exception as e:
            logging.error(f"Error analyzing patches: {e}")
            raise

    async def generate_report(self) -> None:
        """Generate comprehensive patch analysis report."""
        try:
            patch_info = await self.analyze_patches()
            analysis = await self.generate_analysis(self._create_analysis_prompt(patch_info))

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_file = self.log_dir / f"patch_analysis_{timestamp}.txt"

            with open(report_file, 'w') as f:
                f.write("Ubuntu Patch Analysis Report\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write("=" * 80 + "\n\n")

                sections = [
                    ("Executive Summary", {
                        "Total Updates": patch_info.total_updates,
                        "Security Updates": patch_info.security_updates,
                        "Critical Updates": patch_info.critical_updates,
                        "Last Patched": patch_info.last_patched,
                        "Reboot Required": "Yes" if patch_info.reboot_required else "No"
                    }),
                    ("AI Analysis and Recommendations", {"content": analysis}),
                    ("Kernel Updates", patch_info.kernel_updates),
                    ("Service-Impacting Updates", patch_info.service_impacting),
                    ("System Package Updates", patch_info.system_packages)
                ]

                for section_name, content in sections:
                    f.write(f"\n{section_name}\n")
                    f.write("-" * 50 + "\n")

                    if isinstance(content, dict):
                        if "content" in content:
                            f.write(content["content"])
                        else:
                            for key, value in content.items():
                                f.write(f"{key}: {value}\n")
                    elif isinstance(content, list):
                        for item in content:
                            f.write(f"- {item}\n")

                f.write("\n" + "=" * 80 + "\n")
                f.write("Raw Update Data:\n")
                f.write(json.dumps(patch_info.update_details, indent=2))

            logging.info(f"Analysis report generated: {report_file}")
            print(f"\nReport generated: {report_file}")

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            print(f"Error generating report: {e}")

async def main():
    """Main function to run the patch analyzer."""
    print("\n=== Ubuntu Patch Analysis System ===")
    analyzer = UbuntuPatchAnalyzer()

    try:
        print("\nAnalyzing system patches...")
        await analyzer.generate_report()
        print("\nAnalysis complete. Check the logs directory for the report.")

    except KeyboardInterrupt:
        print("\nAnalysis interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Error in main: {e}")

if __name__ == "__main__":
    asyncio.run(main())