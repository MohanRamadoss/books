import ollama
import psutil
import platform
import subprocess
import time
import logging
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

@dataclass
class SystemMetrics:
    """Store system metrics."""
    timestamp: str
    hostname: str
    os_version: str
    kernel_version: str
    uptime: str
    cpu_usage: float
    memory_used: float
    memory_total: float
    swap_used: float
    swap_total: float
    disk_usage: Dict[str, Any]
    updates_pending: int
    security_updates: int

class UbuntuMonitor:
    def __init__(self):
        """Initialize monitoring system."""
        self.setup_logging()
        
    def setup_logging(self):
        """Setup logging configuration."""
        log_dir = os.path.expanduser('~/ubuntu_monitor/logs')
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            filename=os.path.join(log_dir, 'monitor.log'),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def run_command(self, command: str) -> Dict[str, Any]:
        """Execute shell command safely."""
        try:
            result = subprocess.run(
                command.split(),
                capture_output=True,
                text=True,
                check=True
            )
            return {"success": True, "output": result.stdout}
        except subprocess.CalledProcessError as e:
            return {"success": False, "error": str(e)}

    def get_system_metrics(self) -> SystemMetrics:
        """Collect system metrics."""
        try:
            # System info
            uname = platform.uname()
            hostname = uname.node
            kernel = uname.release
            
            # Get OS version
            with open('/etc/os-release') as f:
                os_info = dict(line.strip().split('=', 1) for line in f if '=' in line)
            os_version = os_info.get('VERSION_ID', '').strip('"')
            
            # Get uptime
            uptime_cmd = self.run_command("uptime -p")
            uptime = uptime_cmd["output"].strip() if uptime_cmd["success"] else "Unknown"
            
            # Resource usage
            cpu_usage = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_metrics = {
                'total': disk.total / (1024**3),  # Convert to GB
                'used': disk.used / (1024**3),
                'free': disk.free / (1024**3),
                'percent': disk.percent
            }
            
            # Update information
            updates = self.check_updates()
            
            return SystemMetrics(
                timestamp=datetime.now().isoformat(),
                hostname=hostname,
                os_version=os_version,
                kernel_version=kernel,
                uptime=uptime,
                cpu_usage=cpu_usage,
                memory_used=memory.used / (1024**3),
                memory_total=memory.total / (1024**3),
                swap_used=swap.used / (1024**3),
                swap_total=swap.total / (1024**3),
                disk_usage=disk_metrics,
                updates_pending=updates['total'],
                security_updates=updates['security']
            )
            
        except Exception as e:
            logging.error(f"Error collecting metrics: {e}")
            raise

    def check_updates(self) -> Dict[str, int]:
        """Check for system updates."""
        try:
            # Update package list
            self.run_command("sudo apt-get update -qq")
            
            # Check upgradable packages
            upgrade_cmd = self.run_command("apt list --upgradable")
            
            updates = {
                'total': 0,
                'security': 0
            }
            
            if upgrade_cmd["success"]:
                lines = upgrade_cmd["output"].split('\n')
                updates['total'] = len([l for l in lines if '/' in l])
                updates['security'] = len([l for l in lines if '-security' in l])
                
            return updates
            
        except Exception as e:
            logging.error(f"Error checking updates: {e}")
            return {'total': 0, 'security': 0}

    def analyze_metrics(self, metrics: SystemMetrics) -> Dict[str, Any]:
        """Use Ollama to analyze system metrics."""
        prompt = f"""
        As a system administrator, analyze these Ubuntu server metrics:

        System Information:
        - Hostname: {metrics.hostname}
        - OS Version: Ubuntu {metrics.os_version}
        - Kernel: {metrics.kernel_version}
        - Uptime: {metrics.uptime}

        Resource Usage:
        - CPU Usage: {metrics.cpu_usage:.2f}%
        - Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB
        - Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB
        - Disk Usage: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)

        Updates:
        - Total Updates Pending: {metrics.updates_pending}
        - Security Updates: {metrics.security_updates}

        Please provide:
        1. System health assessment
        2. Resource usage analysis
        3. Security recommendations
        4. Performance optimization suggestions
        5. Maintenance tasks needed
        """

        response = ollama.chat(
            model='llama3.2',
            messages=[{'role': 'user', 'content': prompt}]
        )

        return {
            'timestamp': metrics.timestamp,
            'analysis': response.message.content,
            'metrics': metrics.__dict__
        }

    def print_report(self, metrics: SystemMetrics, analysis: Dict[str, Any]):
        """Print formatted monitoring report."""
        print("\n" + "="*50)
        print(f"Ubuntu Server Monitoring Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*50)
        
        print("\nSystem Information:")
        print(f"Hostname: {metrics.hostname}")
        print(f"OS Version: Ubuntu {metrics.os_version}")
        print(f"Kernel: {metrics.kernel_version}")
        print(f"Uptime: {metrics.uptime}")
        
        print("\nResource Usage:")
        print(f"CPU Usage: {metrics.cpu_usage:.2f}%")
        print(f"Memory: {metrics.memory_used:.2f}GB / {metrics.memory_total:.2f}GB")
        print(f"Swap: {metrics.swap_used:.2f}GB / {metrics.swap_total:.2f}GB")
        print(f"Disk: {metrics.disk_usage['used']:.1f}GB / {metrics.disk_usage['total']:.1f}GB ({metrics.disk_usage['percent']}%)")
        
        print("\nUpdates:")
        print(f"Total Updates Pending: {metrics.updates_pending}")
        print(f"Security Updates: {metrics.security_updates}")
        
        print("\nAI Analysis:")
        print("-"*50)
        print(analysis['analysis'])
        print("="*50)

    def monitor(self, interval: int = 300):
        """Run continuous monitoring."""
        print("\nUbuntu Server Monitoring System")
        print("="*50)
        print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("Log Directory: ~/ubuntu_monitor/logs")
        print("="*50)
        
        try:
            while True:
                metrics = self.get_system_metrics()
                analysis = self.analyze_metrics(metrics)
                self.print_report(metrics, analysis)
                
                # Save to log file
                log_dir = os.path.expanduser('~/ubuntu_monitor/logs')
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                with open(os.path.join(log_dir, f'metrics_{timestamp}.json'), 'w') as f:
                    json.dump(analysis, f, indent=2)
                
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\nMonitoring stopped by user")
        except Exception as e:
            print(f"\nError: {e}")
            logging.error(f"Monitoring failed: {e}")

if __name__ == "__main__":
    monitor = UbuntuMonitor()
    monitor.monitor()