#!/usr/bin/env python3

"""
Ubuntu SSHD Security Analyzer using Mistral
Requirements: 
- pip install ollama
"""

import subprocess
import logging
import os
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any
from dataclasses import dataclass

UBUNTU_SECURITY_RULES = {
    "PermitRootLogin": "no",
    "PasswordAuthentication": "no",
    "PubkeyAuthentication": "yes",
    "Protocol": "2",
    "X11Forwarding": "no",
    "MaxAuthTries": "3",
    "PermitEmptyPasswords": "no",
    "ClientAliveInterval": "300",
    "ClientAliveCountMax": "2",
    "UsePAM": "yes",
    "AllowAgentForwarding": "no",
    "AllowTcpForwarding": "no",
    "PrintMotd": "no",
    "PrintLastLog": "yes",
    "TCPKeepAlive": "no",
    "Compression": "no",
    "StrictModes": "yes",
    "MaxSessions": "2",
    "LoginGraceTime": "30"
}

@dataclass
class UbuntuSSHDConfig:
    """Ubuntu SSHD Configuration"""
    config_path: str
    config_data: Dict[str, str]
    apparmor_status: str
    ufw_status: str
    permissions: Dict[str, str]
    service_status: str

class UbuntuSSHDAnalyzer:
    def __init__(self):
        self.config_path = "/etc/ssh/sshd_config"
        self.log_dir = Path("./ubuntu_sshd_audit")
        self.log_dir.mkdir(exist_ok=True)
        self.setup_logging()

    def setup_logging(self):
        logging.basicConfig(
            filename=self.log_dir / "ubuntu_sshd_audit.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def check_ubuntu_version(self) -> str:
        """Verify Ubuntu version"""
        try:
            with open('/etc/lsb-release', 'r') as f:
                for line in f:
                    if 'DISTRIB_RELEASE' in line:
                        return line.split('=')[1].strip()
        except Exception as e:
            logging.error(f"Error checking Ubuntu version: {e}")
            return "Unknown"

    def read_sshd_config(self) -> Dict[str, str]:
        """Read SSHD configuration"""
        config = {}
        try:
            with open(self.config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            key, value = line.split(None, 1)
                            config[key.lower()] = value
                        except ValueError:
                            continue
        except Exception as e:
            logging.error(f"Error reading config: {e}")
        return config

    def check_apparmor_status(self) -> str:
        """Check AppArmor status"""
        try:
            result = subprocess.run(
                ['aa-status'], 
                capture_output=True, 
                text=True
            )
            return result.stdout
        except Exception as e:
            logging.error(f"Error checking AppArmor: {e}")
            return f"Error: {str(e)}"

    def check_ufw_status(self) -> str:
        """Check UFW firewall status"""
        try:
            result = subprocess.run(
                ['ufw', 'status'], 
                capture_output=True, 
                text=True
            )
            return result.stdout
        except Exception as e:
            logging.error(f"Error checking UFW: {e}")
            return f"Error: {str(e)}"

    def check_permissions(self) -> Dict[str, str]:
        """Check SSH directory and key permissions"""
        paths = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/var/empty/sshd'
        ]

        permissions = {}
        for path in paths:
            try:
                result = subprocess.run(
                    f"ls -l {path}", 
                    shell=True, 
                    capture_output=True, 
                    text=True
                )
                permissions[path] = result.stdout.strip()
            except Exception as e:
                permissions[path] = f"Error: {str(e)}"
        return permissions

    def analyze_security(self, config: Dict[str, str]) -> List[str]:
        """Analyze security configuration"""
        issues = []

        for key, recommended_value in UBUNTU_SECURITY_RULES.items():
            current_value = config.get(key.lower(), "Not set")
            if current_value != recommended_value:
                issues.append(f"Configuration issue: {key} is set to '{current_value}' but should be '{recommended_value}'")

        return issues

    def generate_report(self) -> str:
        """Generate security audit report"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.log_dir / f"ubuntu_sshd_audit_{timestamp}.txt"

        try:
            ubuntu_version = self.check_ubuntu_version()
            config = self.read_sshd_config()
            apparmor_status = self.check_apparmor_status()
            ufw_status = self.check_ufw_status()
            permissions = self.check_permissions()
            security_issues = self.analyze_security(config)

            with open(report_file, 'w') as f:
                f.write("=== Ubuntu SSHD Security Audit Report ===\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write(f"Ubuntu Version: {ubuntu_version}\n")
                f.write("=" * 50 + "\n\n")

                f.write("1. System Security Status\n")
                f.write("-" * 30 + "\n")
                f.write("AppArmor Status:\n")
                f.write(apparmor_status + "\n\n")
                f.write("UFW Status:\n")
                f.write(ufw_status + "\n\n")

                f.write("2. SSHD Configuration\n")
                f.write("-" * 30 + "\n")
                for key, value in config.items():
                    f.write(f"{key}: {value}\n")
                f.write("\n")

                f.write("3. Security Issues\n")
                f.write("-" * 30 + "\n")
                for issue in security_issues:
                    f.write(f"- {issue}\n")
                f.write("\n")

                f.write("4. File Permissions\n")
                f.write("-" * 30 + "\n")
                for path, perms in permissions.items():
                    f.write(f"\n{path}:\n{perms}\n")

            return str(report_file)

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            return f"Error generating report: {str(e)}"

def main():
    """Main function"""
    print("\n=== Ubuntu SSHD Security Analyzer ===")

    if os.geteuid() != 0:
        print("This script requires root privileges.")
        return

    analyzer = UbuntuSSHDAnalyzer()

    try:
        print("\nAnalyzing SSHD configuration...")
        report_path = analyzer.generate_report()
        print(f"\nAudit complete! Report generated: {report_path}")
    except KeyboardInterrupt:
        print("\nAudit interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main error: {e}")

if __name__ == "__main__":
    main()