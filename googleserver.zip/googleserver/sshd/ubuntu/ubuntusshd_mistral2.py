#!/usr/bin/env python3

"""
Ubuntu SSHD Security Analyzer using Mistral
Requirements: 
- pip install ollama
- pip install asyncio
"""

import subprocess
import logging
import os
import json
import ollama
import asyncio
import time
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache, wraps

# Security configuration rules
UBUNTU_SECURITY_RULES = {
    "PermitRootLogin": "no",
    "PasswordAuthentication": "no",
    "PubkeyAuthentication": "yes",
    "Protocol": "2",
    "X11Forwarding": "no",
    "MaxAuthTries": "3",
    "PermitEmptyPasswords": "no",
    "ClientAliveInterval": "300",
    "ClientAliveCountMax": "2",
    "UsePAM": "yes",
    "AllowAgentForwarding": "no",
    "AllowTcpForwarding": "no",
    "PrintMotd": "no",
    "PrintLastLog": "yes",
    "TCPKeepAlive": "no",
    "Compression": "no",
    "StrictModes": "yes",
    "MaxSessions": "2",
    "LoginGraceTime": "30"
}

def performance_monitor(name: str):
    """Performance monitoring decorator"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            result = await func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    return decorator

@dataclass
class SecurityStatus:
    """Security status data structure"""
    apparmor: str
    ufw: str
    service: str
    permissions: Dict[str, str]

class UbuntuSSHDAnalyzer:
    """Enhanced Ubuntu SSHD Security Analyzer"""

    def __init__(self):
        self.config_path = "/etc/ssh/sshd_config"
        self.log_dir = Path("./ubuntu_sshd_audit")
        self.log_dir.mkdir(exist_ok=True)
        self.setup_logging()
        self.performance_metrics = {}

        # Initialize components
        self.executor = ThreadPoolExecutor(max_workers=3)

        # Initialize Ollama client
        try:
            self.llm = ollama.Client()
            ollama.generate(model="mistral", prompt="test")
            logging.info("Successfully connected to Ollama")
        except Exception as e:
            logging.error(f"Failed to initialize Ollama: {e}")
            raise Exception("Failed to initialize AI model. Please ensure Ollama is running with Mistral model installed.")

    def setup_logging(self):
        """Configure logging"""
        logging.basicConfig(
            filename=self.log_dir / "ubuntu_sshd_audit.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    @performance_monitor("ai_analysis")
    async def get_ai_analysis(self, data: Dict[str, Any]) -> str:
        """Get AI-powered analysis using Mistral with optimized prompt"""
        try:
            # Construct focused prompt
            prompt = f"""
            Analyze Ubuntu SSHD security configuration:
            Version: {data['version']}
            Issues: {len(data['security_issues'])}
            Status:
            - AppArmor: {'Enabled' if 'enabled' in data['security_status']['apparmor'].lower() else 'Disabled'}
            - UFW: {'Active' if 'active' in data['security_status']['ufw'].lower() else 'Inactive'}

            Provide:
            1. Critical security issues
            2. Immediate actions needed
            3. Hardening recommendations
            """

            response = await asyncio.to_thread(
                ollama.generate,
                model="mistral",
                prompt=prompt,
                stream=False,
                options={
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "max_tokens": 500
                }
            )

            return response['response']
        except Exception as e:
            logging.error(f"AI analysis error: {e}")
            return f"Error performing AI analysis: {str(e)}"

    @lru_cache(maxsize=32)
    def get_cached_config(self, config_hash: str) -> Dict[str, str]:
        """Cached configuration reader"""
        return self.read_sshd_config()

    @performance_monitor("system_info")
    async def gather_system_info(self) -> SecurityStatus:
        """Gather system information concurrently"""
        tasks = [
            self.executor.submit(self.check_apparmor_status),
            self.executor.submit(self.check_ufw_status),
            self.executor.submit(self.check_sshd_service_status),
            self.executor.submit(self.check_permissions)
        ]

        results = await asyncio.gather(*[
            asyncio.wrap_future(task) for task in tasks
        ])

        return SecurityStatus(
            apparmor=results[0],
            ufw=results[1],
            service=results[2],
            permissions=results[3]
        )

    def check_ubuntu_version(self) -> str:
        """Get Ubuntu version"""
        try:
            with open('/etc/lsb-release', 'r') as f:
                for line in f:
                    if 'DISTRIB_RELEASE' in line:
                        return line.split('=')[1].strip()
        except Exception as e:
            logging.error(f"Error checking Ubuntu version: {e}")
            return "Unknown"

    def read_sshd_config(self) -> Dict[str, str]:
        """Read SSHD configuration"""
        config = {}
        try:
            with open(self.config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            key, value = line.split(None, 1)
                            config[key.lower()] = value
                        except ValueError:
                            continue
        except Exception as e:
            logging.error(f"Error reading config: {e}")
        return config

    def check_apparmor_status(self) -> str:
        """Check AppArmor status"""
        try:
            result = subprocess.run(['aa-status'], capture_output=True, text=True)
            return result.stdout
        except Exception as e:
            logging.error(f"Error checking AppArmor: {e}")
            return f"Error: {str(e)}"

    def check_ufw_status(self) -> str:
        """Check UFW firewall status"""
        try:
            result = subprocess.run(['ufw', 'status'], capture_output=True, text=True)
            return result.stdout
        except Exception as e:
            logging.error(f"Error checking UFW: {e}")
            return f"Error: {str(e)}"

    def check_permissions(self) -> Dict[str, str]:
        """Check SSH directory and key permissions"""
        paths = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/var/empty/sshd'
        ]

        permissions = {}
        for path in paths:
            try:
                result = subprocess.run(
                    f"ls -l {path}", 
                    shell=True, 
                    capture_output=True, 
                    text=True
                )
                permissions[path] = result.stdout.strip()
            except Exception as e:
                permissions[path] = f"Error: {str(e)}"
        return permissions

    def check_sshd_service_status(self) -> str:
        """Check SSHD service status"""
        try:
            result = subprocess.run(
                ['systemctl', 'status', 'ssh'], 
                capture_output=True, 
                text=True
            )
            return result.stdout
        except Exception as e:
            logging.error(f"Error checking SSHD service: {e}")
            return f"Error: {str(e)}"

    def analyze_security(self, config: Dict[str, str]) -> List[str]:
        """Analyze security configuration"""
        issues = []
        for key, recommended_value in UBUNTU_SECURITY_RULES.items():
            current_value = config.get(key.lower(), "Not set")
            if current_value != recommended_value:
                issues.append(
                    f"Configuration issue: {key} is set to '{current_value}' "
                    f"but should be '{recommended_value}'"
                )
        return issues

    @performance_monitor("report_generation")
    async def generate_report(self) -> str:
        """Generate security audit report with async operations"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.log_dir / f"ubuntu_sshd_audit_{timestamp}.txt"

        try:
            # Gather data concurrently
            system_info = await self.gather_system_info()
            config = self.read_sshd_config()
            security_issues = self.analyze_security(config)

            # Prepare data for AI analysis
            analysis_data = {
                "version": self.check_ubuntu_version(),
                "config": config,
                "security_status": {
                    "apparmor": system_info.apparmor,
                    "ufw": system_info.ufw,
                    "service": system_info.service
                },
                "security_issues": security_issues
            }

            # Get AI analysis
            ai_analysis = await self.get_ai_analysis(analysis_data)

            # Generate report content
            report_sections = [
                "=== Ubuntu SSHD Security Audit Report ===",
                f"Generated: {datetime.now().isoformat()}",
                f"Ubuntu Version: {analysis_data['version']}",
                "=" * 50,
                "\n1. AI Security Analysis",
                ai_analysis,
                "\n2. System Status",
                "AppArmor Status:",
                system_info.apparmor,
                "\nUFW Status:",
                system_info.ufw,
                "\nSSHD Service Status:",
                system_info.service,
                "\n3. Security Issues",
                *[f"- {issue}" for issue in security_issues],
                "\n4. File Permissions",
                *[f"{path}:\n{perms}" for path, perms in system_info.permissions.items()],
                "\n=== End of Report ==="
            ]

            # Write report
            with open(report_file, 'w') as f:
                f.write('\n'.join(report_sections))

            return str(report_file)

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            return f"Error generating report: {str(e)}"

async def main():
    """Async main function"""
    print("\n=== Ubuntu SSHD Security Analyzer ===")

    if os.geteuid() != 0:
        print("This script requires root privileges.")
        return

    try:
        analyzer = UbuntuSSHDAnalyzer()
        print("\nInitializing security analysis...")
        print("Checking system configuration...")

        report_path = await analyzer.generate_report()

        print(f"\nAudit complete! Report generated: {report_path}")

    except KeyboardInterrupt:
        print("\nAudit interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main error: {e}")

if __name__ == "__main__":
    asyncio.run(main())