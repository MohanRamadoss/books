#!/usr/bin/env python3

"""
RHEL SSHD Security Analyzer using Mistral - Fixed Version
Requirements: 
- pip install ollama asyncio
"""

import subprocess
import logging
import os
import json
import ollama
import asyncio
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache, wraps

# Security configuration rules remain the same
RHEL_SECURITY_RULES = {
    "PermitRootLogin": "no",
    "PasswordAuthentication": "no",
    "PubkeyAuthentication": "yes",
    "Protocol": "2",
    "X11Forwarding": "no",
    "MaxAuthTries": "3",
    "PermitEmptyPasswords": "no",
    "ClientAliveInterval": "300",
    "ClientAliveCountMax": "2",
    "UsePAM": "yes",
    "AllowAgentForwarding": "no",
    "AllowTcpForwarding": "no",
    "PrintMotd": "no",
    "PrintLastLog": "yes",
    "TCPKeepAlive": "no",
    "Compression": "no",
    "StrictModes": "yes",
    "MaxSessions": "2",
    "LoginGraceTime": "30"
}

def performance_monitor(name: str):
    """Performance monitoring decorator"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            result = await func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    return decorator

@dataclass
class SecurityStatus:
    """Security status data structure"""
    selinux: str
    firewalld: str
    service: str
    permissions: Dict[str, str]

class RHELSSHDAnalyzer:
    def __init__(self):
        self.config_path = "/etc/ssh/sshd_config"
        self.log_dir = Path("./rhel_sshd_audit")
        self.log_dir.mkdir(exist_ok=True)
        self.setup_logging()
        self.executor = ThreadPoolExecutor(max_workers=4)

        # Initialize Ollama
        try:
            self.llm = ollama.Client()
            self._warmup_model()
            logging.info("Successfully initialized Ollama")
        except Exception as e:
            logging.error(f"Failed to initialize Ollama: {e}")
            raise

    def setup_logging(self):
        """Configure logging"""
        logging.basicConfig(
            filename=self.log_dir / "rhel_sshd_audit.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def _warmup_model(self):
        """Warm up the Mistral model"""
        try:
            ollama.generate(
                model="mistral",
                prompt="test",
                options={"temperature": 0.3, "top_p": 0.9}
            )
        except Exception as e:
            logging.warning(f"Model warmup failed: {e}")

    @performance_monitor("config_read")
    def read_sshd_config(self) -> Dict[str, str]:
        """Read SSHD configuration"""
        config = {}
        try:
            with open(self.config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            key, value = line.split(None, 1)
                            config[key.lower()] = value
                        except ValueError:
                            continue
        except Exception as e:
            logging.error(f"Error reading config: {e}")
        return config

    def check_rhel_version(self) -> str:
        """Get RHEL version"""
        try:
            with open('/etc/redhat-release', 'r') as f:
                return f.read().strip()
        except Exception as e:
            logging.error(f"Error checking RHEL version: {e}")
            return "Unknown"

    @performance_monitor("ai_analysis")
    async def get_ai_analysis(self, data: Dict[str, Any]) -> str:
        """Get AI-powered analysis"""
        try:
            prompt = f"""
            Analyze RHEL SSHD security configuration:
            Version: {data['version']}
            Issues: {len(data['security_issues'])}
            Status:
            - SELinux: {'Enabled' if 'enabled' in data['security_status']['selinux'].lower() else 'Disabled'}
            - FirewallD: {'Active' if 'running' in data['security_status']['firewalld'].lower() else 'Inactive'}

            Provide:
            1. Critical issues
            2. Required fixes
            3. SELinux/FirewallD recommendations
            """

            response = await asyncio.to_thread(
                ollama.generate,
                model="mistral",
                prompt=prompt,
                stream=False,
                options={
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "max_tokens": 500
                }
            )

            return response['response']
        except Exception as e:
            logging.error(f"AI analysis error: {e}")
            return f"Error performing AI analysis: {str(e)}"

    async def check_selinux_status(self) -> str:
        """Check SELinux status"""
        try:
            proc = await asyncio.create_subprocess_exec(
                'sestatus',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
            return stdout.decode()
        except Exception as e:
            logging.error(f"Error checking SELinux: {e}")
            return f"Error: {str(e)}"

    async def check_firewalld_status(self) -> str:
        """Check FirewallD status"""
        try:
            proc = await asyncio.create_subprocess_exec(
                'firewall-cmd', '--state',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await proc.communicate()
            return stdout.decode()
        except Exception as e:
            logging.error(f"Error checking FirewallD: {e}")
            return f"Error: {str(e)}"

    async def check_permissions_async(self) -> Dict[str, str]:
        """Check permissions asynchronously"""
        paths = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/var/empty/sshd'
        ]

        async def check_path(path: str) -> Tuple[str, str]:
            try:
                proc = await asyncio.create_subprocess_shell(
                    f"ls -lZ {path}",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await proc.communicate()
                return path, stdout.decode().strip()
            except Exception as e:
                return path, f"Error: {str(e)}"

        results = await asyncio.gather(*[check_path(path) for path in paths])
        return dict(results)

    def analyze_security(self, config: Dict[str, str]) -> List[str]:
        """Analyze security configuration"""
        issues = []
        for key, recommended_value in RHEL_SECURITY_RULES.items():
            current_value = config.get(key.lower(), "Not set")
            if current_value != recommended_value:
                issues.append(
                    f"Configuration issue: {key} is set to '{current_value}' "
                    f"but should be '{recommended_value}'"
                )
        return issues

    @performance_monitor("report_generation")
    async def generate_report(self) -> str:
        """Generate security audit report"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.log_dir / f"rhel_sshd_audit_{timestamp}.txt"

        try:
            # Gather all data concurrently
            selinux_status, firewalld_status, permissions = await asyncio.gather(
                self.check_selinux_status(),
                self.check_firewalld_status(),
                self.check_permissions_async()
            )

            # Read config and analyze security
            config = self.read_sshd_config()
            security_issues = self.analyze_security(config)

            # Prepare data for AI analysis
            analysis_data = {
                "version": self.check_rhel_version(),
                "config": config,
                "security_status": {
                    "selinux": selinux_status,
                    "firewalld": firewalld_status
                },
                "permissions": permissions,
                "security_issues": security_issues
            }

            # Get AI analysis
            ai_analysis = await self.get_ai_analysis(analysis_data)

            # Generate report content
            report_content = [
                "=== RHEL SSHD Security Audit Report ===",
                f"Generated: {datetime.now().isoformat()}",
                f"RHEL Version: {analysis_data['version']}",
                "=" * 50,
                "\n1. AI Security Analysis",
                ai_analysis,
                "\n2. System Status",
                "SELinux Status:",
                selinux_status,
                "\nFirewallD Status:",
                firewalld_status,
                "\n3. Security Issues",
                *[f"- {issue}" for issue in security_issues],
                "\n4. File Permissions and SELinux Contexts",
                *[f"\n{path}:\n{perms}" for path, perms in permissions.items()],
                "\n=== End of Report ==="
            ]

            # Write report
            with open(report_file, 'w') as f:
                f.write('\n'.join(report_content))

            return str(report_file)

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            return f"Error generating report: {str(e)}"

async def main():
    """Async main function"""
    print("\n=== RHEL SSHD Security Analyzer ===")

    if os.geteuid() != 0:
        print("This script requires root privileges.")
        return

    try:
        analyzer = RHELSSHDAnalyzer()
        print("\nInitializing security analysis...")
        print("Checking system configuration...")

        report_path = await analyzer.generate_report()

        print(f"\nAudit complete! Report generated: {report_path}")

    except KeyboardInterrupt:
        print("\nAudit interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main error: {e}")

if __name__ == "__main__":
    asyncio.run(main())