#!/usr/bin/env python3

"""
RHEL SSHD Security Analyzer using Mistral - Optimized Version
Requirements: 
- pip install ollama asyncio
"""

import subprocess
import logging
import os
import json
import ollama
import asyncio
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache, wraps

# Security configuration rules
RHEL_SECURITY_RULES = {
    "PermitRootLogin": "no",
    "PasswordAuthentication": "no",
    # ... [previous rules remain the same]
}

def performance_monitor(name: str):
    """Performance monitoring decorator"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            result = await func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logging.info(f"Performance {name}: {elapsed_time:.2f}s")
            return result

        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    return decorator

@dataclass
class SecurityStatus:
    """Security status data structure"""
    selinux: str
    firewalld: str
    service: str
    permissions: Dict[str, str]

class RHELSSHDAnalyzer:
    def __init__(self):
        self.config_path = "/etc/ssh/sshd_config"
        self.log_dir = Path("./rhel_sshd_audit")
        self.log_dir.mkdir(exist_ok=True)
        self.setup_logging()

        # Initialize thread pool
        self.executor = ThreadPoolExecutor(max_workers=4)

        # Initialize Ollama with optimized settings
        try:
            self.llm = ollama.Client()
            # Warm up the model
            self._warmup_model()
            logging.info("Successfully initialized Ollama")
        except Exception as e:
            logging.error(f"Failed to initialize Ollama: {e}")
            raise

    def _warmup_model(self):
        """Warm up the Mistral model"""
        try:
            ollama.generate(
                model="mistral",
                prompt="test",
                options={"temperature": 0.3, "top_p": 0.9}
            )
        except Exception as e:
            logging.warning(f"Model warmup failed: {e}")

    def setup_logging(self):
        """Configure logging"""
        logging.basicConfig(
            filename=self.log_dir / "rhel_sshd_audit.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    @performance_monitor("ai_analysis")
    async def get_ai_analysis(self, data: Dict[str, Any]) -> str:
        """Optimized AI analysis using Mistral"""
        try:
            # Construct focused prompt
            prompt = f"""
            Analyze RHEL SSHD security configuration:
            Version: {data['version']}
            Issues: {len(data['security_issues'])}
            Status:
            - SELinux: {'Enabled' if 'enabled' in data['security_status']['selinux'].lower() else 'Disabled'}
            - FirewallD: {'Active' if 'running' in data['security_status']['firewalld'].lower() else 'Inactive'}

            Provide:
            1. Critical issues
            2. Required fixes
            3. SELinux/FirewallD recommendations
            """

            response = await asyncio.to_thread(
                ollama.generate,
                model="mistral",
                prompt=prompt,
                stream=False,
                options={
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "max_tokens": 500
                }
            )

            return response['response']
        except Exception as e:
            logging.error(f"AI analysis error: {e}")
            return f"Error performing AI analysis: {str(e)}"

    @lru_cache(maxsize=32)
    def get_cached_config(self, config_hash: str) -> Dict[str, str]:
        """Cached configuration reader"""
        return self.read_sshd_config()

    async def gather_system_info(self) -> Tuple[SecurityStatus, Dict[str, str]]:
        """Gather system information concurrently"""
        async def run_command(cmd: List[str]) -> str:
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await proc.communicate()
                return stdout.decode()
            except Exception as e:
                logging.error(f"Command error {cmd}: {e}")
                return f"Error: {str(e)}"

        # Run commands concurrently
        selinux, firewalld, service = await asyncio.gather(
            run_command(['sestatus']),
            run_command(['firewall-cmd', '--state']),
            run_command(['systemctl', 'status', 'sshd'])
        )

        # Get permissions in parallel
        permissions = await self.check_permissions_async()

        return SecurityStatus(
            selinux=selinux,
            firewalld=firewalld,
            service=service,
            permissions=permissions
        ), self.read_sshd_config()

    async def check_permissions_async(self) -> Dict[str, str]:
        """Async permission checker"""
        paths = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/var/empty/sshd'
        ]

        async def check_path(path: str) -> Tuple[str, str]:
            try:
                proc = await asyncio.create_subprocess_shell(
                    f"ls -lZ {path}",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, _ = await proc.communicate()
                return path, stdout.decode().strip()
            except Exception as e:
                return path, f"Error: {str(e)}"

        results = await asyncio.gather(*[check_path(path) for path in paths])
        return dict(results)

    @performance_monitor("report_generation")
    async def generate_report(self) -> str:
        """Generate security audit report with async operations"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.log_dir / f"rhel_sshd_audit_{timestamp}.txt"

        try:
            # Gather data concurrently
            system_info, config = await self.gather_system_info()

            # Analyze security in parallel
            security_issues = await asyncio.to_thread(
                self.analyze_security, config
            )

            # Prepare data for AI analysis
            analysis_data = {
                "version": self.check_rhel_version(),
                "config": config,
                "security_status": {
                    "selinux": system_info.selinux,
                    "firewalld": system_info.firewalld,
                    "service": system_info.service
                },
                "security_issues": security_issues
            }

            # Get AI analysis
            ai_analysis = await self.get_ai_analysis(analysis_data)

            # Generate report content efficiently
            report_content = self.format_report(
                analysis_data, system_info, ai_analysis, security_issues
            )

            # Write report asynchronously
            await asyncio.to_thread(
                self.write_report, report_file, report_content
            )

            return str(report_file)

        except Exception as e:
            logging.error(f"Error generating report: {e}")
            return f"Error generating report: {str(e)}"

    def format_report(self, analysis_data, system_info, ai_analysis, security_issues):
        """Format report content efficiently"""
        return "\n".join([
            "=== RHEL SSHD Security Audit Report ===",
            f"Generated: {datetime.now().isoformat()}",
            f"RHEL Version: {analysis_data['version']}",
            "=" * 50,
            "\n1. AI Security Analysis",
            ai_analysis,
            "\n2. System Status",
            f"SELinux Status:\n{system_info.selinux}",
            f"\nFirewallD Status:\n{system_info.firewalld}",
            f"\nSSHD Service Status:\n{system_info.service}",
            "\n3. Security Issues",
            *[f"- {issue}" for issue in security_issues],
            "\n4. File Permissions and SELinux Contexts",
            *[f"\n{path}:\n{perms}" for path, perms in system_info.permissions.items()],
            "\n=== End of Report ==="
        ])

    def write_report(self, report_file: Path, content: str):
        """Write report to file"""
        with open(report_file, 'w') as f:
            f.write(content)

async def main():
    """Async main function"""
    print("\n=== RHEL SSHD Security Analyzer ===")

    if os.geteuid() != 0:
        print("This script requires root privileges.")
        return

    try:
        analyzer = RHELSSHDAnalyzer()
        print("\nInitializing security analysis...")
        print("Checking system configuration...")

        report_path = await analyzer.generate_report()

        print(f"\nAudit complete! Report generated: {report_path}")

    except KeyboardInterrupt:
        print("\nAudit interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main error: {e}")

if __name__ == "__main__":
    asyncio.run(main())