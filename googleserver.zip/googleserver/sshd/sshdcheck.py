#!/usr/bin/env python3

import ollama
import subprocess
import logging
import os
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any
from dataclasses import dataclass

@dataclass
class SSHDSecurityCheck:
    """SSHD Security Check Results"""
    config: Dict[str, Any]
    permissions: Dict[str, str]
    platform: Dict[str, str]
    security_checks: Dict[str, Any]
    vulnerabilities: List[str]
    recommendations: List[str]

class SSHDSecurityAuditor:
    def __init__(self, config_path: str = "/etc/ssh/sshd_config"):
        """Initialize SSHD Security Auditor"""
        self.config_path = config_path
        self.setup_logging()
        self.llm = ollama.Client()
        self.model = "llama2:latest"

    def setup_logging(self):
        """Setup logging configuration"""
        log_dir = Path("./sshd_audit_logs")
        log_dir.mkdir(exist_ok=True)
        logging.basicConfig(
            filename=log_dir / "sshd_audit.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def get_platform_info(self) -> Dict[str, str]:
        """Detect platform and version"""
        platform_info = {"os": "unknown", "version": "unknown"}

        try:
            if os.path.exists('/etc/redhat-release'):
                with open('/etc/redhat-release', 'r') as f:
                    platform_info['os'] = 'rhel'
                    platform_info['version'] = f.read().strip()
            elif os.path.exists('/etc/lsb-release'):
                with open('/etc/lsb-release', 'r') as f:
                    platform_info['os'] = 'ubuntu'
                    for line in f:
                        if 'DISTRIB_RELEASE' in line:
                            platform_info['version'] = line.split('=')[1].strip()
        except Exception as e:
            logging.error(f"Platform detection error: {e}")

        return platform_info

    def read_sshd_config(self) -> Dict[str, Any]:
        """Read and parse SSHD configuration"""
        config = {}
        try:
            with open(self.config_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            key, value = line.split(None, 1)
                            config[key.lower()] = value
                        except ValueError:
                            continue
        except Exception as e:
            logging.error(f"Config reading error: {e}")
        return config

    def check_permissions(self) -> Dict[str, str]:
        """Check SSHD related file permissions"""
        critical_files = [
            self.config_path,
            '/etc/ssh/ssh_host_*_key',
            '/etc/ssh/ssh_host_*_key.pub',
            '/etc/ssh',
            '/var/empty/sshd'
        ]

        permissions = {}
        for path in critical_files:
            try:
                result = subprocess.run(
                    f"ls -l {path}", 
                    shell=True, 
                    capture_output=True, 
                    text=True
                )
                permissions[path] = result.stdout.strip()
            except Exception as e:
                permissions[path] = f"Error: {str(e)}"
        return permissions

    def perform_security_checks(self) -> Dict[str, Any]:
        """Perform comprehensive security checks"""
        checks = {}
        platform = self.get_platform_info()

        try:
            # Common checks
            checks['sshd_version'] = subprocess.run(
                ['sshd', '-V'], 
                capture_output=True, 
                text=True
            ).stderr.strip()

            checks['sshd_service'] = subprocess.run(
                ['systemctl', 'status', 'sshd'], 
                capture_output=True, 
                text=True
            ).stdout

            checks['listening_ports'] = subprocess.run(
                ['ss', '-tlnp', '|', 'grep', 'sshd'], 
                shell=True, 
                capture_output=True, 
                text=True
            ).stdout

            # Platform specific checks
            if platform['os'] == 'rhel':
                checks['selinux'] = subprocess.run(
                    ['sestatus'], 
                    capture_output=True, 
                    text=True
                ).stdout
                checks['firewall'] = subprocess.run(
                    ['firewall-cmd', '--list-all'], 
                    capture_output=True, 
                    text=True
                ).stdout

            elif platform['os'] == 'ubuntu':
                checks['apparmor'] = subprocess.run(
                    ['aa-status'], 
                    capture_output=True, 
                    text=True
                ).stdout
                checks['ufw'] = subprocess.run(
                    ['ufw', 'status'], 
                    capture_output=True, 
                    text=True
                ).stdout

        except Exception as e:
            logging.error(f"Security check error: {e}")
            checks['error'] = str(e)

        return checks

    def ai_security_analysis(self, data: SSHDSecurityCheck) -> Dict[str, Any]:
        """Perform AI-powered security analysis"""
        prompt = f"""
        As a cybersecurity expert, analyze this SSHD configuration and provide a detailed security assessment:

        Platform: {data.platform['os']} {data.platform['version']}

        Configuration:
        {json.dumps(data.config, indent=2)}

        File Permissions:
        {json.dumps(data.permissions, indent=2)}

        Security Checks:
        {json.dumps(data.security_checks, indent=2)}

        Provide:
        1. Critical Security Issues
        2. Configuration Weaknesses
        3. Compliance Issues
        4. Detailed Recommendations
        5. Hardening Steps

        Format the response in clear sections with specific, actionable items.
        """

        try:
            response = self.llm.generate(
                model=self.model,
                prompt=prompt,
                stream=False
            )
            return {
                'analysis': response['response'],
                'status': 'success'
            }
        except Exception as e:
            logging.error(f"AI analysis error: {e}")
            return {
                'analysis': f"Error performing analysis: {str(e)}",
                'status': 'error'
            }

    def generate_report(self, data: SSHDSecurityCheck, analysis: Dict[str, Any]) -> str:
        """Generate comprehensive security report"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"sshd_security_report_{timestamp}.txt"

        try:
            with open(report_file, 'w') as f:
                f.write("=== SSHD Security Audit Report ===\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write(f"Platform: {data.platform['os']} {data.platform['version']}\n")
                f.write("=" * 50 + "\n\n")

                f.write("1. System Information\n")
                f.write("-" * 30 + "\n")
                f.write(f"OS: {data.platform['os']}\n")
                f.write(f"Version: {data.platform['version']}\n\n")

                f.write("2. SSHD Configuration\n")
                f.write("-" * 30 + "\n")
                f.write(json.dumps(data.config, indent=2) + "\n\n")

                f.write("3. File Permissions\n")
                f.write("-" * 30 + "\n")
                f.write(json.dumps(data.permissions, indent=2) + "\n\n")

                f.write("4. Security Checks\n")
                f.write("-" * 30 + "\n")
                f.write(json.dumps(data.security_checks, indent=2) + "\n\n")

                f.write("5. AI Security Analysis\n")
                f.write("-" * 30 + "\n")
                f.write(analysis['analysis'] + "\n\n")

                f.write("=" * 50 + "\n")
                f.write("End of Report\n")

            return report_file
        except Exception as e:
            logging.error(f"Report generation error: {e}")
            return f"Error generating report: {str(e)}"

    def run_audit(self):
        """Run complete SSHD security audit"""
        print("\nStarting SSHD Security Audit...")

        try:
            # Collect data
            platform_info = self.get_platform_info()
            print(f"\nDetected Platform: {platform_info['os']} {platform_info['version']}")

            config = self.read_sshd_config()
            print("Configuration read complete...")

            permissions = self.check_permissions()
            print("Permission checks complete...")

            security_checks = self.perform_security_checks()
            print("Security checks complete...")

            # Compile data
            audit_data = SSHDSecurityCheck(
                config=config,
                permissions=permissions,
                platform=platform_info,
                security_checks=security_checks,
                vulnerabilities=[],
                recommendations=[]
            )

            # AI Analysis
            print("\nPerforming AI security analysis...")
            analysis = self.ai_security_analysis(audit_data)

            # Generate Report
            print("\nGenerating report...")
            report_file = self.generate_report(audit_data, analysis)

            print(f"\nAudit complete! Report generated: {report_file}")
            return report_file

        except Exception as e:
            logging.error(f"Audit error: {e}")
            print(f"\nError during audit: {e}")
            return None

def main():
    """Main function"""
    print("\n=== SSHD Security Auditor ===")

    # Check for root privileges
    if os.geteuid() != 0:
        print("This script requires root privileges.")
        sys.exit(1)

    auditor = SSHDSecurityAuditor()

    try:
        auditor.run_audit()
    except KeyboardInterrupt:
        print("\nAudit interrupted by user")
    except Exception as e:
        print(f"\nError: {e}")
        logging.error(f"Main error: {e}")

if __name__ == "__main__":
    main()