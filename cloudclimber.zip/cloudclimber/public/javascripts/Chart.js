<script>
                // Your JavaScript code goes here
                // For example:
                const ctx = document.getElementById('studyTimeChart').getContext('2d'); // Get the 2D rendering context
                const chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'], // Days of the week
                             datasets: [
                                    {
                                        label: 'Terraform (Total: Y hours)'
                                        data: [2, 2.5, 3, 2, 2.5, 3, 1], // Daily study time for Terraform
                                        borderColor: '#aee595',
                                        backgroundColor: 'rgba(174, 229, 149, 0.5)',
                                        pointRadius: 5,
                                        pointHitRadius: 10,
                                    },
                                    {
                                        label: 'Docker (Total: Y hours)',
                                        data: [1, 1.5, 2, 1.5, 2, 2.5, 2], // Daily study time for Docker
                                        borderColor: '#95a5a6',
                                        backgroundColor: 'rgba(149, 165, 166, 0.5)',
                                        pointRadius: 5,
                                        pointHitRadius: 10,
                                    },
                                    {
                                        label: 'Kubernetes (Total: Y hours)'',
                                        data: [1.5, 2, 2.5, 2, 2.5, 3, 2], // Daily study time for Kubernetes
                                        borderColor: '#56b7f1',
                                        backgroundColor: 'rgba(86, 183, 241, 0.5)',
                                        pointRadius: 5,
                                        pointHitRadius: 10,
                                    },
                                    {
                                        label: 'AWS (Total: Y hours)',
                                        data: [2.5, 3, 3.5, 3, 3.5, 4, 3], // Daily study time for AWS
                                        borderColor: '#f0ad4e',
                                        backgroundColor: 'rgba(240, 173, 78, 0.5)',
                                        pointRadius: 5,
                                        pointHitRadius: 10,
                                    },
                                ],
                            ],
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Hours Studied'
                                    },
                                }],
                            },
                            tooltips: {
                                enabled: true,
                                mode: 'index',
                                intersect: false,
                            },
                        },
                    });
                    
                    // Show total study time in chart title or legend
                    chart.options.title = {
                        display: true,
                        text: 'Study Time by Course (Total: X hours)', // Replace X with the total study time for all courses
                    };
                    chart.data.datasets[0].label += ' (Total: Y hours)'; // Replace Y with the total study time for Terraform
                    chart.data.datasets[1].label += ' (Total: Z hours)'; // Replace Z with the total study time for Docker
                    // Repeat for other courses
                    
                    chart.update();
                
        </script>