var express = require('express');
const OpenAI = require("openai");
var router = express.Router();
const openai = new OpenAI();

// Initialize the cache
const cache = new Map();


router.get("/info", async (req, res) => {
    try {
        const { keyword } = req.query;
        const prompt = `Please give a simple explanation of what ${keyword} is? Additionally, I'd like to know the most effective 3 paths to learn ${keyword}, including any resources, tutorials, and best practices you would recommend for someone new to this concept.`;
        // Check if the result is in the cache
        if (cache.has(prompt)) {
            return res.json({ content: cache.get(prompt) });
        }

        const completion = await openai.chat.completions.create({
            messages: [
                { role: "system", content: prompt, },
            ],
            model: "gpt-4-0125-preview",
        });

        // Store the result in the cache
        cache.set(prompt, completion.choices[0].message.content);

        res.json({ content: completion.choices[0].message.content });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.get("/questions", async (req, res) => {
    try {
        const { keyword } = req.query;
        const prompt = `Generate 2 single-choice question and 2 short-answer question in JSON format that are specifically related to ${keyword}. Example: [ { "type": "choice", "question": "xxx", "choices": [ "AAA", "BBB", "CCC", "DDD" ], "answer": 0 }, { "type": "short-question", "question": "xxx", } ]`;
           // Check if the result is in the cache
           if (cache.has(prompt)) {
            return res.json({ content: cache.get(prompt) });
        }
        
        const completion = await openai.chat.completions.create({
            messages: [
                { role: "system", content: prompt, },
            ],
            model: "gpt-4-0125-preview",
        });

         // Store the result in the cache
         cache.set(prompt, completion.choices[0].message.content);

         
        res.json(JSON.parse(completion.choices[0].message.content));
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.post("/assistant", async (req, res) => {
    try {
        const { messages } = req.body;
        const prompt = 'You are an AI assistant for learning software engineering. Here are messages before: ' + messages;
          // Check if the result is in the cache
       if (cache.has(prompt)) {
            return res.json({ content: cache.get(prompt) });
        }
        const completion = await openai.chat.completions.create({
            messages: [
                { role: "system", content: prompt, },
            ],
            model: "gpt-4-0125-preview",
        });
        // Store the result in the cache
        cache.set(prompt, completion.choices[0].message.content);
        
        res.json({ content: completion.choices[0].message.content });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});



router.get("/coding-challenge", async (req, res) => {
    try {
        const { topic } = req.query;
        const prompt = `Generate a coding challenge related to ${topic}. The challenge should include a problem statement, example input and output, and a hint.`;

        // Check if the result is in the cache
        if (cache.has(prompt)) {
            return res.json({ content: cache.get(prompt) });
        }

        const completion = await openai.chat.completions.create({
            messages: [
                { role: "system", content: prompt, },
            ],
            model: "gpt-4-0125-preview",
        });

        // Store the result in the cache
        cache.set(prompt, completion.choices[0].message.content);

        res.json({ content: completion.choices[0].message.content });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});



module.exports = router;
