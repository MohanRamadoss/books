var express = require('express');
const sqlite3 = require('sqlite3');
var router = express.Router();
const db = new sqlite3.Database('data.db');

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT,
      password TEXT
    )
  `);
});

router.post('/signup', (req, res) => {
  const { username, password } = req.body;

  
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
    if (err) {
      console.error('Error during signup: ', err);
      res.status(500).json({ error: 'An error occurred' });
    } else if (row) {
      res.status(400).json({ error: 'Username already exists' });
    } else {
      
      db.run(
          'INSERT INTO users (username, password) VALUES (?, ?)',
          [username, password],
          function (err) {
            if (err) {
              console.error('Error during signup: ', err);
              res.status(500).json({ error: 'An error occurred' });
            } else {
              const userId = this.lastID; 
              res.json({ message: 'Signup successful', id: userId });
            }
          }
      );
    }
  });
});


router.post('/signin', (req, res) => {
  const { username, password } = req.body;

  
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
    if (err) {
      console.error('Error during signin: ', err);
      res.status(500).json({ error: 'An error occurred' });
    } else if (!row) {
      res.status(401).json({ error: 'Invalid username or password' });
    } else {
      
      req.session.userId = row.id;
      res.json({ message: 'Signin successful' });
    }
  });
});

router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.redirect('/dashboard');
    }

    res.clearCookie('sid');
    res.redirect('/');
  });
});

module.exports = router;
